flag = bytearray(b"MINUTEMAN{flag-was-here}")
flag = flag[::-1]
i = 0
while i < 0o1312:
        new_i = 30 - 0o2 * i
        flag[i % len(flag)] = flag[new_i % len(flag)]
        i = new_i
flag = map(lambda x: x+1 if x > 105 else x, flag)
print(bytearray(flag))