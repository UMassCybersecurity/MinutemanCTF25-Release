#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>

#include <errno.h>

#include <sys/mman.h>

struct ld_format {
    size_t length;
    unsigned char bytes;
};

struct locals {
    char buf[0x300];
    int (*fn)(const char *);
};

__attribute__((constructor)) void ignore_me() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(int argc, char **argv) {
    int fd, i;
    char *bytes;
    void  *mapping;
    struct ld_format *header;
    struct locals loc;

    loc.fn = puts;

    // open a user controlled file
    if (argc < 2) {
        printf("Usage: %s <inputFile>\n", argv[0]);
        return (-1);
    }
    
    //fd = open(argv[1], O_RDWR | 040000 | O_SYNC);
    fd = open(argv[1], O_RDWR | O_SYNC);
    if (fd == -1) {
        printf("Open failed with %d\n", errno);
        return (-2);
    }

    // map it file backed into memory
    mapping = mmap(0, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED,  fd, 0);
    if (mapping == (void *) 0xffffffff) {
        printf("Mmap failed with %d\n", errno);
        return (-3);
    }

    // read a length from start of file
    header = (struct ld_format *) mapping;

    // check length for too large
    if (header->length > 0x300) {
        printf("Length must be <= than 0x300: 0x%08x\n", header->length);
        return (-4);
    }

    // reread length and copy it
    sleep(2);
    //msync(mapping, 0x1000, MS_SYNC | MS_INVALIDATE);
    bytes = (char *) &(header->bytes);
    for (i = 0; i < header->length; i++) {
        loc.buf[i] = bytes[i];
    }

    i = 0;;
    while (i < sizeof (loc.buf)) {
        loc.buf[i] = toupper(loc.buf[i]);
        i++;
    }

    // do something else that makes sure you cant write too far
    printf("Read the following from %s:\n", argv[1]);
    (*loc.fn)(loc.buf);

    return (0);
}
